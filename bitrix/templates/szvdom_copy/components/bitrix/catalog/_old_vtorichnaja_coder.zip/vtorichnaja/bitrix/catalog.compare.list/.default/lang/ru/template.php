<?
$MESS["CATALOG_COMPARE_ELEMENTS"] = "Список сравниваемых элементов";
$MESS["CATALOG_DELETE"] = "Убрать";
$MESS["CP_BCCL_TPL_MESS_COMPARE_COUNT"] = "Количество элементов в списке сравнения:";
$MESS["CP_BCCL_TPL_MESS_COMPARE_PAGE"] = "Перейти на страницу сравнения";
?>