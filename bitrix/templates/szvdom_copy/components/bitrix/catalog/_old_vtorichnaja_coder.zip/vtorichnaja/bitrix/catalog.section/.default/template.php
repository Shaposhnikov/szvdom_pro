<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);
$xml = simplexml_load_file("http://szvdom.ru/include/xml/SiteData.xml") or die("Error: Cannot create object");
if (!empty($arResult['ITEMS']))
{
    $random = rand(2,8);
    ?>
<div class="buildMainPage">
    <ul>
        <?foreach( $arResult['ITEMS'] as $mainKey => $value){
            $blocks = $xml->xpath("/Ads/Blocks/Block[@id='" . $value["PROPERTIES"]["SECOND_ID"]["VALUE"]. "']");
            if (!empty($blocks[0]["avatar"])){
                $imago = (string)$blocks[0]["avatar"];
            }else{
                $imago = $value["PROPERTIES"]["AVATAR"]["VALUE"];
            }
            ?>
    <li onclick="location.href = '<?=$value["DETAIL_PAGE_URL"];?>'">
        <?
        if (!empty($value["PROPERTIES"]["RED_LABEL_MARK"]["VALUE"])){
            echo '<div class="redLabelMark">'.$value["PROPERTIES"]["RED_LABEL_MARK"]["VALUE"].'</div>';
        }
        ?>
        <a href="<?=$value["DETAIL_PAGE_URL"]?>">
            <?if (!empty($value["PREVIEW_PICTURE"])  && $value["PREVIEW_PICTURE"]["SRC"] != "/bitrix/templates/szvdom/components/bitrix/catalog/szv/bitrix/catalog.section/.default/images/no_photo.png"){
                echo "<img width='225' height='175' src='/thumb/225x172xcut".$value["PREVIEW_PICTURE"]["SRC"]."' alt='".$value["NAME"]."' title='".$value["NAME"]."' />";
            }else{
                if (!empty($imago)){
                    echo '<img width="225" height="175" src="/thumb/225x172xcut/include/images/'.$imago.'" title="'.$value["NAME"].'" alt="'.$value["NAME"].'" />';
                }else{
                    echo "<img width='225' height='175' src='/thumb/225x172xcut/bitrix/templates/szvdom/components/bitrix/catalog/szv/bitrix/catalog.section/.default/images/no_photo.png' alt='".$value["NAME"]."' title='".$value["NAME"]."' />";
                }
            }?>
        </a>
        <div style="clear: both;"></div>
        <a href="<?=$value["DETAIL_PAGE_URL"]?>" class="buildName"><?=$value["NAME"]?></a>
        <div class="buildText">
            <p style="color:#2579CB;">
                <?foreach ($value["PROPERTIES"]["REGION"]["VALUE"] as $key => $subValue) {
                    if ($key != (count($value["PROPERTIES"]["REGION"]["VALUE"]) - 1)) {?>
                        <?= $subValue; ?>,
                    <?} else {?>
                        <?= $subValue; ?>
                    <?}
                }
                if (count($value["PROPERTIES"]["REGION"]["VALUE"]) == 1){
                    echo ' район';
                }else{
                    echo ' районы';
                }
                ?>
            </p>
            <p style="color:#2579CB;"><span class="subwayLabel inline_m"></span>
            <?= $value["PROPERTIES"]["SUBWAYS"]["VALUE"][0]; ?>
            </p>
            <p><?=$value["PROPERTIES"]["ADDRESS"]["VALUE"];?></p>
            <?
            if ($value["PROPERTIES"]["ENDINGPERIOD"]["VALUE"] != false){
                if (count($value["PROPERTIES"]["ENDINGPERIOD"]["VALUE"]) != 2){?>
                    <p class="mini_on_ab">
                        <span style="font-family: Bold;">Срок сдачи: </span>
                        <?=$value["PROPERTIES"]["ENDINGPERIOD"]["VALUE"][0];?>
                        <?if (strtolower($value["PROPERTIES"]["ENDINGPERIOD"]["VALUE"][0]) != "сдан"){?>
                            г.
                        <?}?>
                    </p>
                <?} else{?>
                <p class="mini_on_ab">
                    <span style="font-family: Bold;">Срок сдачи: </span>
                    <?if ($value["PROPERTIES"]["ENDINGPERIOD"]["VALUE"][0] != $value["PROPERTIES"]["ENDINGPERIOD"]["VALUE"][1]){?>
                    <?=$value["PROPERTIES"]["ENDINGPERIOD"]["VALUE"][0];?> - <?=$value["PROPERTIES"]["ENDINGPERIOD"]["VALUE"][1];?> гг.
                    <?}else{?>
                    <?=$value["PROPERTIES"]["ENDINGPERIOD"]["VALUE"][0];?> г.
                    <?}?>
                </p>
                <?
                }
            }
            ?>
        </div>

        <p class="pseudoButton" style="margin-top: -6px;">от <?= number_format($value["PROPERTIES"]["FLATCOST_PUBLIC"]["VALUE"][0], 0, ',', ' '); ?> Р</p>

        <div class="hiddenDataLi"  onclick="location.href = '<?=$value["DETAIL_PAGE_URL"];?>'">
           <div class="catalog_adv_title">Преимущества</div>
           <div class="catalog_adv_text">
                <span class="catalog_adv_bold"><?=$value["NAME"]?></span>
               <ul>
                <? foreach ($value["PROPERTIES"]["BENEFITS_MAIN"]["VALUE"] as $key => $str) {
                    if ($key > 3){continue;}
                    echo "<li><span>" . $str . "</span></li>";
                } ?>
               </ul>
               <a href="<?=$value["DETAIL_PAGE_URL"]?>" class="catalog_adv_a">Описание объекта</a>
               <div class="gray_hr"></div>
               <a class="catalog_adv_a_akc" href="<?=$value["DETAIL_PAGE_URL"]?>?anchor=specblcs">Акции и скидки</a>
           </div>
        </div>

    </li>
 
  
        <?if ($mainKey == $random){?>
        <li style="position:relative;max-height:360px;">
            <a style="height: 364px;display: block; width: 225px; position:relative " data-who="footer_feedback" class="showIt catalog_woman">
               <span class="catalog_woman_span">Бесплатно для вас!</span>
			   <ul>
					<li><span>консультация по объектам</span></li>
					<li><span>подбор жилья по параметрам</span></li>
					<li><span>подача заявки в ипотеку</span></li>
					<li><span>помощь юриста</span></li>
					<li><span>и многое другое!</span></li>
			   </ul>
			   <div class="green_hr"></div>
			   <div class="catalog_woman_tel">
			   <p>Звоните по телефону:</p>
			   <span class="ya-elama-phone call_phone_1">+7(812) 902-50-50</span>
			    
			   </div>
			  <div class="catalog_woman_but">Отправить заявку</div>
            </a>
        </li>
        <?}

        }?>
    </ul>

        <div style="clear: both;"></div>
    <?if ($arParams["DISPLAY_BOTTOM_PAGER"])
	{
		?>
        <? echo $arResult["NAV_STRING"]; ?><?
	}?>
    </div>
    <?
}

?>
