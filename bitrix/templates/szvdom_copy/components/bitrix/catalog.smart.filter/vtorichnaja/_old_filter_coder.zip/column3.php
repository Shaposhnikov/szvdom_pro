<div class="bx_filter_block">

		<div class="bx_filter_parameters_box_container">

		<input value="Сбросить" class="bx_filter_search_reset" type="submit" id="del_filter" name="del_filter">

		<a href="#" onclick="" style="background: url('/bitrix/templates/szvdom/images/icons/filter3.png') left no-repeat;padding-left: 25px;" data-status="close">Срочная продажа</a>

		<div style="clear: both;"></div>
		<input class="bx_filter_search_button" type="submit" id="set_filter" name="set_filter" value="ПОКАЗАТЬ ВАРИАНТЫ">
		<div class="bx_filter_popup_result left" id="modef" style="display:none">
			Выбрано: <span id="modef_num">0</span>							<span class="arrow"></span>
			<a href="">Показать варианты</a>
		</div>
	</div>
</div>