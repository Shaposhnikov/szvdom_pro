<?
$MESS ['MFT_SMALL_NAME'] = "Название товара";
$MESS ['MFT_SMALL_EMAIL'] = "E-mail";
$MESS ['MFT_SMALL_PHONE'] = "Ваш телефон";
$MESS ['MFT_SMALL_AMOUNT'] = "Количество";
$MESS ['MFT_SMALL_REGION'] = "Регион";
$MESS ['MFT_SMALL_CAPTCHA'] = "Защита от автоматических сообщений";
$MESS ['MFT_SMALL_CAPTCHA_CODE'] = "Введите слово на картинке";
$MESS ['MFT_SMALL_SUBMIT'] = "Жду звонка";
?>