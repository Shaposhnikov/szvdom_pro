<?
$sSectionName = "Объекты";
$arDirProperties = Array(

);
?>