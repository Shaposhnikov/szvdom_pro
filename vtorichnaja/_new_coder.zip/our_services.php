<? if (strstr($APPLICATION->GetCurPage(),'/vtorichnaja/')) {?>

<style>
@import url(https://fonts.googleapis.com/css?family=Open+Sans:700&subset=latin,cyrillic);
#our_services
{
    font-family: 'Open Sans', sans-serif;
    padding: 25px 0px;background-color: white;
}
#our_services h2
{
    font-size: 22px;
    color: #535353;
    text-transform: uppercase;
    margin-bottom: 25px;
    margin-left: 39px;
    margin-top: 50px;
}
#our_services table
{
    text-align:center;
    text-transform:uppercase;
    padding:10px 0px;
}
#our_services a
{
    color: #276bb2;
    font-size: 13px;
}
#our_services a span
{
    display:block;
    margin-top: 19px;
}
</style>
<div id="our_services">
<h2>Воспользуйтесь нашими услугами</h2>
<table width="100%">
    <tr>
        <td width="25px"></td>
        <td valign="top">
            <a href="/uslugi/prodazha-nedvizhimosti/">
                <img src="/bitrix/templates/szvdom/images/service_sale.jpg"/>
                <br/>
                <span>Продать<br/>недвижимость</span>
            </a>
        </td>
        <td valign="top"><a href="/uslugi/otsenka-nedvizhimosti/"><img src="/bitrix/templates/szvdom/images/service_estimate.jpg"/><br/><span>Оценить<br/>недвижимость</span></a></td>
        <td valign="top"><a href="#"><img src="/bitrix/templates/szvdom/images/service_find.jpg"/><br/><span>Подбор<br/>недвижимости</span></a></td>
        <td valign="top"><a href="/sposoby-pokupki/zachet-kvartiry/"><img src="/bitrix/templates/szvdom/images/service_tradein.jpg"/><br/><span>Trade In /<br/> зачет жилья</span></a></td>
        <td valign="top"><a href="#"><img src="/bitrix/templates/szvdom/images/service_subsidii.jpg"/><br/><span>расселение,<br/>субсидии</span></a></td>
        <td valign="top"><a href="/uslugi/yuridicheskoe-soprovozhdenie-sdelok-kupli-prodazhi/">
            <img src="/bitrix/templates/szvdom/images/service_soprov.jpg"/><br/>
            <span>
                юридическое<br/>сопровождение<br/>сделок</span></a></td>
        <td width="25px"></td>
    </tr>
</table>
</div>

<? } ?>